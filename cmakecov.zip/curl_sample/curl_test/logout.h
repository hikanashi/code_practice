#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void logout(const char* logstr);

#ifdef __cplusplus
}
#endif
